/**
 * Landing Page - Passageiros Skema Drive
 * 
 * Design Philosophy: Modernismo Corporativo com Toque Regional
 * - Hierarquia clara e profissional
 * - Integração visual da identidade amapaense
 * - Paleta: Azul corporativo + Verde e Amarelo (cores do Amapá)
 * - Elementos: Hexágonos, linhas diagonais, cards estruturados
 * - Animações: Fade-in, hover suave, parallax leve
 */

import { Button } from "@/components/ui/button";
import { ArrowRight, DollarSign, Gift, MapPin, Phone, Shield, Smartphone } from "lucide-react";
import { useEffect, useState } from "react";

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white text-foreground overflow-hidden">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black transition-all duration-300">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/images/logo-skema.png" alt="Skema Drive" className="h-12 w-auto" />
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#beneficios" className="text-gray-300 hover:text-white transition-colors">
              Benefícios
            </a>
            <a href="#por-que" className="text-gray-300 hover:text-white transition-colors">
              Por que escolher
            </a>
            <Button
              className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-full px-6 py-2 h-auto transition-all duration-300 hover:shadow-lg"
              onClick={() =>
                window.open(
                  "https://play.google.com/store/apps/details?id=br.com.skemadrive.passenger.taximachine",
                  "_blank"
                )
              }
            >
              Baixar App
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-8 md:pt-40 md:pb-16 overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-20 right-0 w-96 h-96 bg-blue-50 rounded-full opacity-40 blur-3xl -z-10"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-green-50 rounded-full opacity-30 blur-3xl -z-10"></div>

        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12 items-center">
            {/* Text Content */}
            <div className="space-y-4 md:space-y-6 animate-fade-in">
              <div className="space-y-2 md:space-y-3">
                <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-blue-900 leading-tight">
                  Conheça a Skema Drive
                </h1>
                <p className="text-lg md:text-2xl font-semibold text-gray-800">
                  O app de corridas feito para o Macapaense economizar
                </p>
              </div>

              <p className="text-base md:text-lg text-gray-700 leading-relaxed max-w-md">
                🚕 Viaje com mais economia, segurança e rapidez — Skema Drive, o app 100% amapaense feito para você!
              </p>

              <div className="bg-gradient-to-r from-green-50 to-yellow-50 border border-green-200 rounded-xl p-4 md:p-6 space-y-2 md:space-y-3">
                <p className="font-semibold text-gray-900 text-sm md:text-base">
                  Ganhe 10% de desconto na sua primeira corrida
                </p>
                <p className="text-gray-700 text-xs md:text-sm">
                  Pague menos do que nos apps tradicionais e conte com uma central de atendimento real, aqui em Macapá, pronta para te ajudar.
                </p>
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative h-64 md:h-full md:min-h-[500px] flex items-center justify-center animate-fade-in-delayed">
              <img
                src="/images/hero-passageiro.png"
                alt="Passageiro usando Skema Drive"
                className="w-full h-full object-contain drop-shadow-2xl hover:drop-shadow-none transition-all duration-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Button Below Hero */}
      <section className="py-4 md:py-8 bg-white text-center">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button
            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-full px-8 py-6 h-auto text-lg font-semibold transition-all duration-300 hover:shadow-xl hover:scale-105 flex items-center gap-2 group mx-auto"
            onClick={() =>
              window.open(
                "https://play.google.com/store/apps/details?id=br.com.skemadrive.passenger.taximachine",
                "_blank"
              )
            }
          >
            Baixar o App
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </section>

      {/* Divider */}
      <div className="relative h-20 bg-gradient-to-b from-transparent to-gray-50 flex items-center justify-center">
        <div className="w-24 h-1 bg-gradient-to-r from-transparent via-blue-300 to-transparent"></div>
      </div>

      {/* Benefits Section */}
      <section id="beneficios" className="py-20 md:py-32 bg-gray-50 relative overflow-hidden">
        {/* Decorative hexagon pattern */}
        <div className="absolute top-10 right-10 w-32 h-32 border-2 border-blue-100 rounded-full opacity-20"></div>
        <div className="absolute bottom-20 left-5 w-40 h-40 border-2 border-green-100 rounded-full opacity-20"></div>

        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-blue-900">
              ⭐ Por que escolher a Skema Drive?
            </h2>
            <p className="text-xl text-gray-700 max-w-2xl mx-auto">
              Tudo que você precisa para viajar com segurança, economia e confiança
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Benefit Card 1 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <DollarSign className="w-7 h-7 text-green-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">💸 Corridas mais baratas</h3>
              <p className="text-gray-700">
                Pague menos do que nos aplicativos tradicionais, sem surpresas no final.
              </p>
            </div>

            {/* Benefit Card 2 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Gift className="w-7 h-7 text-yellow-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">🎁 10% de desconto</h3>
              <p className="text-gray-700">
                Válido para novos passageiros que baixarem o app hoje.
              </p>
            </div>

            {/* Benefit Card 3 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Phone className="w-7 h-7 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">📞 Atendimento humano</h3>
              <p className="text-gray-700">
                Nada de robôs. Fale com alguém da cidade, que entende a cidade.
              </p>
            </div>

            {/* Benefit Card 4 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <MapPin className="w-7 h-7 text-green-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">🏙️ App 100% amapaense</h3>
              <p className="text-gray-700">
                Tecnologia feita aqui, por gente que vive o dia a dia de Macapá.
              </p>
            </div>

            {/* Benefit Card 5 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-red-100 to-red-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Shield className="w-7 h-7 text-red-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">🚘 Segurança e confiança</h3>
              <p className="text-gray-700">
                Motoristas verificados, suporte rápido e um app feito para ser simples e confiável.
              </p>
            </div>

            {/* Benefit Card 6 */}
            <div className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:translate-y-[-4px] border border-gray-100 animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Smartphone className="w-7 h-7 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">📲 App simples e intuitivo</h3>
              <p className="text-gray-700">
                Interface amigável que qualquer pessoa consegue usar com facilidade.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="por-que" className="py-20 md:py-32 bg-black text-white relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gray-900 rounded-full opacity-20 blur-3xl -z-10"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-yellow-600 rounded-full opacity-10 blur-3xl -z-10"></div>

        <div className="container max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Comece sua jornada agora
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Baixe o app Skema Drive e aproveite 10% de desconto na sua primeira corrida. Viaje com economia, segurança e a confiança de quem entende Macapá.
            </p>
          </div>

          <Button
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full px-10 py-7 h-auto text-xl font-bold transition-all duration-300 hover:shadow-2xl hover:scale-105 flex items-center gap-3 mx-auto group"
            onClick={() =>
              window.open(
                "https://play.google.com/store/apps/details?id=br.com.skemadrive.passenger.taximachine",
                "_blank"
              )
            }
          >
            Baixar o App na Play Store
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
          </Button>

          <p className="text-sm text-gray-400">
            Disponível para Android. iOS em breve.
          </p>
        </div>
      </section>
    </div>
  );
}
